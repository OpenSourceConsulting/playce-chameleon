#!/bin/bash
. ./env.sh

$CATALINA_HOME/bin/shutdown.sh

