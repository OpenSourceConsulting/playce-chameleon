#!/bin/bash
. ./env.sh

tail -200f $CATALINA_BASE/logs/$SERVER_NAME.out
